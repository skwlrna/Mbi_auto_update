# Managed K incident shortcut corpus

209 canonical 800x1000 incident frames were examined offline (208 earlier
images plus 2026-10-23 06:08). These fixtures retain only generic Home/End/ESC/Y
shortcut pixels from x550..799/y77..89. The remaining strip pixels are black.
Food fixtures retain only the generic food-menu heading and bottom navigation.
No complete private gameplay frame, player name, chat or inventory is included.

The compiled production matcher is run against each shortcut strip. The 140
non-world screens must not gain key evidence, and the five known normal-field
incidents must retain a baseline or new visual route. The latest Y-button
incident must acquire the new glyph evidence. Five food-navigation strips must
classify as a food list; their dimmed versions must be refused.

`baselineEvidence` and `independentField` are offline observations from the
original images. They are not CLI values, fresh input authorization, or evidence
that two consecutive frames existed. Temporal tests separately reject mixed
glyph/OCR routes, layout changes and missing keys. Real game K-menu transition,
receipt and navigation input remain untested.

The glyph references include two observed Home renderings, including the latest
incident. This is a regression corpus, not an unseen statistical test set.
